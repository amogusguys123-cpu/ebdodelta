# Among Helper AI 2.0

## O que esta versão faz
1. Você toca em "INICIAR GRAVAÇÃO DA PARTIDA".
2. O Android mostra a autorização oficial de captura de tela.
3. Depois de aceitar, o app grava a tela inteira em um único MP4 temporário.
4. Você joga normalmente.
5. Ao tocar em "Parar gravação", o vídeo é finalizado.
6. O vídeo pode ser enviado para um endpoint HTTPS configurado para análise por IA.
7. A API pode devolver o jogador suspeito, uma porcentagem de confiança e os motivos.

O vídeo é armazenado temporariamente no cache do aplicativo e apagado depois da tentativa de envio.

## API
O endpoint configurado deve aceitar:
POST multipart/form-data
campo: video
tipo: video/mp4

Resposta sugerida:
{
  "suspect": "Vermelho",
  "chance": 72,
  "reason": "Eventos observados no vídeo..."
}

## Importante
A versão 2 grava e envia o vídeo completo, mas a IA precisa de um backend capaz de processar vídeo. Uma API de texto comum não consegue automaticamente assistir a um MP4 inteiro.

Também não existe garantia de tokens ilimitados. Para partidas longas, um backend pode dividir o vídeo em segmentos, extrair frames relevantes e gerar um resumo antes da análise final.

## Linguagem
Kotlin

## Tecnologias
Android SDK 35
MediaProjection
MediaRecorder
Foreground Service
HTTP multipart/form-data

## Privacidade
A captura de tela só começa depois da autorização do Android. Não há acesso oculto à tela.


## Gemini API
O aplicativo possui um campo para você inserir sua própria **Gemini API Key**.
A chave não é embutida no código-fonte nem no APK automaticamente.

Para uma versão de produção, recomenda-se usar um backend intermediário para proteger a chave.
