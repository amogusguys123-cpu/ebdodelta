package com.amonghelper.ai

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.io.File

class ScreenRecordService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private lateinit var output: File

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, id: Int): Int {
        if (intent?.getBooleanExtra("bubbleOnly", false) == true) {
            startForegroundNotification("Assistente ativo")
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra("resultCode", -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>("data")
        if (resultCode == -1 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification("Gravando a partida")
        startRecording(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startRecording(resultCode: Int, data: Intent) {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        output = File(cacheDir, "among_match_${System.currentTimeMillis()}.mp4")

        recorder = MediaRecorder(this).apply {
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoEncodingBitRate(5_000_000)
            setVideoFrameRate(30)
            setVideoSize(width, height)
            setOutputFile(output.absolutePath)
            prepare()
        }

        display = projection!!.createVirtualDisplay(
            "AmongHelperAI",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            recorder!!.surface, null, null
        )
        recorder!!.start()
    }

    override fun onDestroy() {
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.reset()
        recorder?.release()
        display?.release()
        projection?.stop()

        if (::output.isInitialized && output.exists()) {
            VideoAnalyzer(this).upload(output)
        }
        super.onDestroy()
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            "recording", "Gravação da partida", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun startForegroundNotification(text: String) {
        startForeground(
            55,
            Notification.Builder(this, "recording")
                .setContentTitle("Among Helper AI")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build()
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
