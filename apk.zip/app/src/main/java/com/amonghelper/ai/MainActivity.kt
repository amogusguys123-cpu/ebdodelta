package com.amonghelper.ai

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.*

class MainActivity : Activity() {
    private val requestCapture = 700
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,28,28,28)
        }

        root.addView(TextView(this).apply {
            text = "Among Helper AI 2.0"
            textSize = 25f
        })
        root.addView(TextView(this).apply {
            text = "Grave a partida inteira com autorização do Android e, ao finalizar, envie o vídeo para sua API para análise."
        })

        val notes = EditText(this).apply {
            hint = "Observações para a IA"
            minLines = 3
        }
        root.addView(notes)

        root.addView(Button(this).apply {
            text = "Configurar API"
            setOnClickListener { configureApi() }
        })

        root.addView(Button(this).apply {
            text = "INICIAR GRAVAÇÃO DA PARTIDA"
            setOnClickListener { requestScreenCapture(notes.text.toString()) }
        })

        root.addView(Button(this).apply {
            text = "Parar gravação"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenRecordService::class.java))
                Toast.makeText(this@MainActivity, "Gravação parada.", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "Ativar bolinha"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    ))
                } else {
                    startService(Intent(this@MainActivity, ScreenRecordService::class.java)
                        .putExtra("bubbleOnly", true))
                }
            }
        })

        setContentView(root)
    }

    private fun requestScreenCapture(notes: String) {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
        getSharedPreferences("session", MODE_PRIVATE).edit()
            .putString("notes", notes).apply()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenRecordService::class.java)
                .putExtra("resultCode", resultCode)
                .putExtra("data", data)
            startForegroundService(intent)
            Toast.makeText(this, "Gravação iniciada. Jogue normalmente e pare quando a partida acabar.", Toast.LENGTH_LONG).show()
        }
    }

    private fun configureApi() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20,10,20,10)
        }
        val url = EditText(this).apply {
            hint = "Endpoint Gemini/backend HTTPS"
            setText(prefs.getString("url",""))
        }
        val key = EditText(this).apply {
            hint = "Gemini API Key (cole aqui)"
            setText(prefs.getString("key",""))
        }
        box.addView(url); box.addView(key)

        AlertDialog.Builder(this)
            .setTitle("Configurar Gemini API")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                prefs.edit().putString("url",url.text.toString())
                    .putString("key",key.text.toString()).apply()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
