package com.amonghelper.ai

import android.content.Context
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class VideoAnalyzer(private val context: Context) {
    private val executor = Executors.newSingleThreadExecutor()

    fun upload(video: File) {
        val prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE)
        val endpoint = prefs.getString("url", "") ?: ""
        val key = prefs.getString("key", "") ?: ""
        if (endpoint.isBlank()) {
            video.delete()
            return
        }

        executor.execute {
            try {
                val boundary = "----AmongHelperBoundary${System.currentTimeMillis()}"
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 30000
                conn.readTimeout = 120000
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                if (key.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $key")

                val out = conn.outputStream
                val head = "--$boundary\r\n" +
                    "Content-Disposition: form-data; name=\"video\"; filename=\"${video.name}\"\r\n" +
                    "Content-Type: video/mp4\r\n\r\n"
                out.write(head.toByteArray())
                video.inputStream().use { input -> input.copyTo(out) }
                out.write("\r\n--$boundary--\r\n".toByteArray())
                out.close()

                val response = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                video.delete()

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, "Análise recebida: $response", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                video.delete()
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, "Falha ao enviar vídeo: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
